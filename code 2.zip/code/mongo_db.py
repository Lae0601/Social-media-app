from faker import Faker
import random
from datetime import datetime, timedelta
from bson import ObjectId
from pymongo import ASCENDING, TEXT

from db_connection import users_collection

def create_indexes():
    users_collection.create_index([("username", ASCENDING)], unique=True)
    users_collection.create_index([("email", ASCENDING)], unique=True)
    users_collection.create_index([("username", ASCENDING), ("email", ASCENDING)])
    users_collection.create_index([("username", TEXT), ("email", TEXT)])
    print("Indexes created.")

def insert_sample_user():
    user = {
        "_id": ObjectId(),
        "username": "axel_loera",
        "email": "axel@lol.com",
        "hashed_password": "jjn2oirn058",
        "created_at": datetime(2025, 3, 20, 12, 0, 0),
        "bio": "Tech enthusiast and gamer.",
        "profile_picture": "https://localhost.com/yo.jpg",
        "preferences": {
            "theme": "dark",
            "notifications": True
        }
    }
    users_collection.insert_one(user)
    print("Sample user inserted.")

def find_by_username(username):
    return users_collection.find_one({"username": username})

def search_users(search_term):
    pipeline = [
        {
            "$match": {
                "$or": [
                    {"username": {"$regex": search_term, "$options": "i"}},
                    {"email": {"$regex": search_term, "$options": "i"}}
                ]
            }
        },
        {"$project": {"_id": 0, "username": 1, "email": 1}}
    ]
    return list(users_collection.aggregate(pipeline))

def group_by_theme():
    pipeline = [
        {"$group": {"_id": "$preferences.theme", "count": {"$sum": 1}}},
        {"$project": {"_id": 0, "theme": "$_id", "count": 1}}
    ]
    return list(users_collection.aggregate(pipeline))

def recent_users(limit=10):
    return list(users_collection.find({}, {"username": 1, "created_at": 1}).sort("created_at", -1).limit(limit))

def count_notifications_enabled():
    return users_collection.count_documents({"preferences.notifications": True})

def average_registrations_last_30_days():
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    pipeline = [
        {"$match": {"created_at": {"$gte": thirty_days_ago}}},
        {
            "$group": {
                "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$created_at"}},
                "count": {"$sum": 1}
            }
        },
        {"$sort": {"_id": 1}}
    ]
    return list(users_collection.aggregate(pipeline))

def populate_random_users(n=50):
    fake = Faker()
    theme_options = ["dark", "light", "solarized"]

    user_list = []
    for _ in range(n):
        user = {
            "_id": ObjectId(),
            "username": fake.user_name(),
            "email": fake.email(),
            "hashed_password": fake.sha256(),
            "created_at": fake.date_time_between(start_date='-1y', end_date='now'),
            "bio": fake.sentence(),
            "profile_picture": fake.image_url(),
            "preferences": {
                "theme": random.choice(theme_options),
                "notifications": random.choice([True, False])
            }
        }
        user_list.append(user)

    result = users_collection.insert_many(user_list)
    print(f"{len(result.inserted_ids)} random users inserted.")

def print_all_users():
    users = users_collection.find({}, {"_id": 0, "username": 1, "email": 1, "created_at": 1})
    for user in users:
        print(user)
