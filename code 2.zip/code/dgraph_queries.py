import pydgraph # type: ignore
import os
import json



def set_schema(client):
    schema = """
        type Usuario {
            username
            email
            bio
            profile_picture
            preferences
            created_at
            follows
            followers
            posts
            comments
            liked_posts
            likes
            memberOf
        }

        type Publicacion {
            title
            content
            timestamp
            postedBy
            comments
            liked_by
        }

        type Comentario {
            content
            timestamp
            postedBy
            comments
        }

        type Grupo {
            name
            description
        }

        username: string @index(exact) .
        email: string @index(exact) .
        bio: string .
        profile_picture: string .
        preferences: string .
        created_at: datetime @index(hour) .
        follows: [uid] @reverse .
        followers: [uid] @reverse .
        posts: [uid] @reverse .
        comments: [uid] @reverse .
        liked_posts: [uid] @reverse .
        likes: [uid] @reverse .
        memberOf: [uid] @reverse .
        title: string @index(fulltext) .
        content: string @index(fulltext) .
        timestamp: datetime @index(hour) .
        postedBy: uid @reverse .
        liked_by: [uid] @reverse .
        name: string @index(exact) .
        description: string .
        """
    op = pydgraph.Operation(schema=schema)
    client.alter(op)
    print("Schema set successfully.")

import json
import pydgraph

def create_data(client):
    txn = client.txn()
    mutations = [
        # ——— Usuarios ———
        {
            'uid': '_:u1',
            'dgraph.type': 'Usuario',
            'username': 'juan_perez',
            'email': 'juan.perez@example.com',
            'bio': 'Engineer and data geek.',
            'profile_picture': 'https://pics.example.com/juan.png',
            'preferences': '["tech", "travel"]',
            'created_at': '2024-12-01T09:00:00Z'
        },
        {
            'uid': '_:u2',
            'dgraph.type': 'Usuario',
            'username': 'maria_gomez',
            'email': 'maria.gomez@example.com',
            'bio': 'Bookworm and coffee lover.',
            'profile_picture': 'https://pics.example.com/maria.png',
            'preferences': '["books", "coffee"]',
            'created_at': '2025-01-15T14:30:00Z'
        },
        {
            'uid': '_:u3',
            'dgraph.type': 'Usuario',
            'username': 'carlos_rd',
            'email': 'carlos.rodriguez@example.com',
            'bio': 'Photographer & traveler.',
            'profile_picture': 'https://pics.example.com/carlos.png',
            'preferences': '["photography", "travel"]',
            'created_at': '2025-02-20T11:15:00Z'
        },
        {
            'uid': '_:u4',
            'dgraph.type': 'Usuario',
            'username': 'ana_lopez',
            'email': 'ana.lopez@example.com',
            'bio': 'Food blogger.',
            'profile_picture': 'https://pics.example.com/ana.png',
            'preferences': '["food", "recipes"]',
            'created_at': '2025-03-05T17:45:00Z'
        },
        {
            'uid': '_:u5',
            'dgraph.type': 'Usuario',
            'username': 'luis_mtz',
            'email': 'luis.martinez@example.com',
            'bio': 'Guitarist & musician.',
            'profile_picture': 'https://pics.example.com/luis.png',
            'preferences': '["music", "guitar"]',
            'created_at': '2025-04-10T08:20:00Z'
        },
        {
            'uid': '_:u6',
            'dgraph.type': 'Usuario',
            'username': 'sofia_ramirez',
            'email': 'sofia.ramirez@example.com',
            'bio': 'Yoga instructor.',
            'profile_picture': 'https://pics.example.com/sofia.png',
            'preferences': '["wellness", "yoga"]',
            'created_at': '2025-04-22T10:00:00Z'
        },

        # ——— Publicaciones ———
        {
            'uid': '_:p1',
            'dgraph.type': 'Publicacion',
            'title': 'My First Post',
            'content': 'Hello world, this is Juan’s first post!',
            'timestamp': '2025-05-01T12:00:00Z',
            'postedBy': {'uid': '_:u1'}
        },
        {
            'uid': '_:p2',
            'dgraph.type': 'Publicacion',
            'title': 'Coffee Recommendations',
            'content': 'Top 5 coffee shops in CDMX.',
            'timestamp': '2025-05-02T09:30:00Z',
            'postedBy': {'uid': '_:u2'}
        },
        {
            'uid': '_:p3',
            'dgraph.type': 'Publicacion',
            'title': 'Photography Tips',
            'content': 'How to capture the golden hour.',
            'timestamp': '2025-05-03T18:20:00Z',
            'postedBy': {'uid': '_:u3'}
        },
        {
            'uid': '_:p4',
            'dgraph.type': 'Publicacion',
            'title': 'Easy Pancakes',
            'content': 'My secret pancake recipe.',
            'timestamp': '2025-05-04T07:15:00Z',
            'postedBy': {'uid': '_:u4'}
        },
        {
            'uid': '_:p5',
            'dgraph.type': 'Publicacion',
            'title': 'New Guitar Gear',
            'content': 'Just got a new Fender Stratocaster!',
            'timestamp': '2025-05-05T20:45:00Z',
            'postedBy': {'uid': '_:u5'}
        },
        {
            'uid': '_:p6',
            'dgraph.type': 'Publicacion',
            'title': 'Morning Yoga Flow',
            'content': 'Try this quick 15‑minute sequence.',
            'timestamp': '2025-05-06T06:00:00Z',
            'postedBy': {'uid': '_:u6'}
        },
        {
            'uid': '_:p7',
            'dgraph.type': 'Publicacion',
            'title': 'Traveling Tips',
            'content': 'How I pack for a week in Europe.',
            'timestamp': '2025-05-07T13:30:00Z',
            'postedBy': {'uid': '_:u3'}
        },
        {
            'uid': '_:p8',
            'dgraph.type': 'Publicacion',
            'title': 'Healthy Recipes',
            'content': 'Smoothie bowls and salads.',
            'timestamp': '2025-05-08T11:00:00Z',
            'postedBy': {'uid': '_:u4'}
        },

        # ——— Comentarios ———
        {
            'uid': '_:c1',
            'dgraph.type': 'Comentario',
            'content': 'Congrats on your first post!',
            'timestamp': '2025-05-01T12:15:00Z',
            'postedBy': {'uid': '_:u2'},
            'comments': {'uid': '_:p1'}
        },
        {
            'uid': '_:c2',
            'dgraph.type': 'Comentario',
            'content': 'I love that coffee list.',
            'timestamp': '2025-05-02T09:45:00Z',
            'postedBy': {'uid': '_:u1'},
            'comments': {'uid': '_:p2'}
        },
        {
            'uid': '_:c3',
            'dgraph.type': 'Comentario',
            'content': 'Great tips, thanks!',
            'timestamp': '2025-05-03T18:50:00Z',
            'postedBy': {'uid': '_:u4'},
            'comments': {'uid': '_:p3'}
        },
        {
            'uid': '_:c4',
            'dgraph.type': 'Comentario',
            'content': 'Can you share more recipes?',
            'timestamp': '2025-05-04T07:45:00Z',
            'postedBy': {'uid': '_:u5'},
            'comments': {'uid': '_:p4'}
        },
        {
            'uid': '_:c5',
            'dgraph.type': 'Comentario',
            'content': 'Sounds relaxing.',
            'timestamp': '2025-05-06T06:30:00Z',
            'postedBy': {'uid': '_:u1'},
            'comments': {'uid': '_:p6'}
        },

        # ——— Grupos ———
        {
            'uid': '_:g1',
            'dgraph.type': 'Grupo',
            'name': 'Tech Enthusiasts',
            'description': 'A place for tech lovers.'
        },
        {
            'uid': '_:g2',
            'dgraph.type': 'Grupo',
            'name': 'Foodies Club',
            'description': 'Recipes, restaurants & more.'
        },

        # ——— Membresías ———
        {'uid': '_:u1', 'memberOf': [{'uid': '_:g1'}]},
        {'uid': '_:u2', 'memberOf': [{'uid': '_:g2'}]},
        {'uid': '_:u3', 'memberOf': [{'uid': '_:g1'}]},
        {'uid': '_:u4', 'memberOf': [{'uid': '_:g2'}]},
        {'uid': '_:u5', 'memberOf': [{'uid': '_:g1'}]},
        {'uid': '_:u6', 'memberOf': [{'uid': '_:g2'}]},

        # ——— Seguimientos cruzados ———
        {'uid': '_:u1', 'follows': [{'uid': '_:u2'}, {'uid': '_:u3'}]},
        {'uid': '_:u2', 'follows': [{'uid': '_:u3'}, {'uid': '_:u4'}]},
        {'uid': '_:u3', 'follows': [{'uid': '_:u4'}, {'uid': '_:u5'}]},
        {'uid': '_:u4', 'follows': [{'uid': '_:u5'}, {'uid': '_:u6'}]},
        {'uid': '_:u5', 'follows': [{'uid': '_:u6'}, {'uid': '_:u1'}]},
        {'uid': '_:u6', 'follows': [{'uid': '_:u1'}, {'uid': '_:u2'}]},

        # ——— Likes cruzados ———
        {'uid': '_:u1', 'likes': [{'uid': '_:p2'}, {'uid': '_:p3'}]},
        {'uid': '_:u2', 'likes': [{'uid': '_:p3'}, {'uid': '_:p4'}]},
        {'uid': '_:u3', 'likes': [{'uid': '_:p1'}, {'uid': '_:p5'}]},
        {'uid': '_:u4', 'likes': [{'uid': '_:p5'}, {'uid': '_:p6'}]},
        {'uid': '_:u5', 'likes': [{'uid': '_:p6'}, {'uid': '_:p7'}]},
        {'uid': '_:u6', 'likes': [{'uid': '_:p7'}, {'uid': '_:p8'}]},
    ]

    try:
        response = txn.mutate(set_obj=mutations)
        txn.commit()
        print(f"Commit successful! UIDs assigned: {response.uids}")
    finally:
        txn.discard()

def delete_user_by_username(client, username):
    txn = client.txn()
    try:
        query = """
        query getUser($u: string) {
            users(func: eq(username, $u)) {
                uid
            }
        }"""
        res = client.txn(read_only=True).query(query, variables={'$u': username})
        data = json.loads(res.json)
        for user in data["users"]:
            txn.mutate(del_obj={"uid": user["uid"]})
            print(f"Deleted user: {username} (UID: {user['uid']})")
        txn.commit()
    finally:
        txn.discard()


def search_user(client, username):
    query = """
    query follows($u: string) {
        user(func: eq(username, $u)) {
            username
            follows { username }
            ~follows { username }  # followers
        }
    }
    """
    res = client.txn(read_only=True).query(query, variables={'$u': username})
    result = json.loads(res.json)
    print(json.dumps(result, indent=2))


def drop_all(client):
    print("Dropping all data and schema...")
    client.alter(pydgraph.Operation(drop_all=True))
    print("Drop all complete.")


def get_follow_data(client, username):
    query = """
    query getFollowData($u: string) {
        user(func: eq(username, $u)) {
            username
            follows { username }
            ~follows { username }
        }
    }
    """
    res = client.txn(read_only=True).query(query, variables={"$u": username})
    result = json.loads(res.json)
    print(json.dumps(result, indent=2))


def get_post_details(client, content):
    query = """
    query getPost($c: string) {
        post(func: eq(content, $c)) {
            content
            created_at
            author { username }
            ~comments {
                content
                author { username }
            }
            ~liked_by { username }
        }
    }
    """
    res = client.txn(read_only=True).query(query, variables={"$c": content})
    result = json.loads(res.json)
    print(json.dumps(result, indent=2))


def mutual_followers(client, username):
    query = """
    query mutual($u: string) {
        user(func: eq(username, $u)) {
            uid as uid
            username
        }

        mutual(func: type(User)) @filter(uid_in(follows, uid(uid))) {
            username
            follows @filter(uid_in(~follows, uid(uid))) {
                username
            }
        }
    }
    """
    res = client.txn(read_only=True).query(query, variables={"$u": username})
    result = json.loads(res.json)
    print(json.dumps(result, indent=2))


def search_users_by_domain(client, domain="@example.com"):
    query = f"""
    {{
        users(func: regexp(email, /{domain}$/)) {{
            username
            email
        }}
    }}
    """
    res = client.txn(read_only=True).query(query)
    result = json.loads(res.json)
    print(json.dumps(result, indent=2))


def recent_posts(client, username):
    query = """
    query recentPosts($u: string) {
        user(func: eq(username, $u)) {
            username
            posts(orderdesc: created_at, first: 5) {
                content
                created_at
            }
        }
    }
    """
    res = client.txn(read_only=True).query(query, variables={"$u": username})
    result = json.loads(res.json)
    print(json.dumps(result, indent=2))


def search_comments_keyword(client, keyword):
    query = """
    query searchComments($k: string) {
        comments(func: anyoftext(content, $k)) {
            content
            author { username }
            post {
                content
            }
        }
    }
    """
    res = client.txn(read_only=True).query(query, variables={"$k": keyword})
    result = json.loads(res.json)
    print(json.dumps(result, indent=2))


def top_user_engagement(client):
    query = """
    {
        var(func: type(User)) {
            postCount as count(posts)
            commentCount as count(comments)
        }

        engagement(func: type(User), orderdesc: val(postCount), first: 5) {
            username
            posts: val(postCount)
            comments: val(commentCount)
        }
    }
    """
    res = client.txn(read_only=True).query(query)
    result = json.loads(res.json)
    print(json.dumps(result, indent=2))


def get_all_users(client):
    """
    Queries and returns all Usuario nodes with their main fields
    and outgoing/incoming edges according to the schema.
    """
    query = """
    {
      allUsers(func: type(Usuario)) {
        uid
        username
        email
        bio
        profile_picture
        preferences
        created_at
        follows {
          uid
          username
        }
        followers {
          uid
          username
        }
        posts {
          uid
          title
        }
        comments {
          uid
          content
        }
        liked_posts {
          uid
          title
        }
        likes {
          uid
          username
        }
        memberOf {
          uid
          name
        }
      }
    }
    """
    txn = client.txn(read_only=True)
    try:
        res = txn.query(query)
        data = json.loads(res.json)
        return data.get("allUsers", [])
    finally:
        txn.discard()


def get_users_followed_by(client, user_uid: str):
    query = f"""
    {{
      user(func: uid({user_uid})) {{
        follows {{
          uid
          username
        }}
      }}
    }}
    """
    txn = client.txn(read_only=True)
    try:
        res = txn.query(query)
        data = json.loads(res.json)
        return data.get("user", [])
    finally:
        txn.discard()


def get_users_who_liked_post(client, post_id: str):
    query = """
    query getLikes($pid: string) {
      post(func: eq(id, $pid)) {
        liked_by {
          uid
          username
        }
      }
    }
    """
    variables = {"$pid": post_id}
    txn = client.txn(read_only=True)
    try:
        res = txn.query(query, variables=variables)
        data = json.loads(res.json)
        return data.get("post", [])
    finally:
        txn.discard()


def count_comments_on_post(client, post_id: str) -> int:
    query = """
    query countComments($pid: string) {
      post(func: eq(id, $pid)) {
        comment_count: count(comments)
      }
    }
    """
    variables = {"$pid": post_id}
    txn = client.txn(read_only=True)
    try:
        res = txn.query(query, variables=variables)
        data = json.loads(res.json)
        if data.get("post") and len(data["post"]) > 0:
            return data["post"][0].get("comment_count", 0)
        return 0
    finally:
        txn.discard()


def suggest_mutual_friends(client, user_uid: str):
    query = f"""
    {{
      var(func: uid({user_uid})) {{
        user_follows as follows
      }}

      mutual_friends(func: uid(user_follows)) @filter(uid_in(follows, {user_uid})) {{
        uid
        username
      }}
    }}
    """
    txn = client.txn(read_only=True)
    try:
        res = txn.query(query)
        data = json.loads(res.json)
        return data.get("mutual_friends", [])
    finally:
        txn.discard()


def check_if_user_follows(client, follower_uid: str, followee_uid: str) -> bool:
    query = f"""
    {{
      user(func: uid({follower_uid})) {{
        follows @filter(uid({followee_uid})) {{
          uid
        }}
      }}
    }}
    """
    txn = client.txn(read_only=True)
    try:
        res = txn.query(query)
        data = json.loads(res.json)
        # Si el arreglo follows tiene elementos, significa que sí sigue
        user = data.get("user", [])
        if user and "follows" in user[0] and len(user[0]["follows"]) > 0:
            return True
        return False
    finally:
        txn.discard()