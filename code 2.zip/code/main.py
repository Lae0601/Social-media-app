import os
import json
import pydgraph # type: ignore
import dgraph_queries as dq
from datetime import timedelta
from datetime import datetime

from uuid import UUID
from datetime import datetime, timedelta
from sample_data import load_sample_data
from cassandra_setup import connect, setup_all
from cassandra.cluster import Cluster

from pymongo import MongoClient, ASCENDING, TEXT # type: ignore
from datetime import datetime, timedelta

from cassandra_queries import (
    init_queries,
    get_recent_logins,
    get_user_posts_since,
    get_user_posts_in_range,
    get_recent_posts_last_24h,
    get_recent_page_visits
)
from cassandra_inserts import (
    init_inserts,
    insert_user_login,
    insert_user_post,
    insert_user_visit, print_all_data
)
from sample_data import load_sample_data

from mongo_db import (
    insert_sample_user,
    create_indexes,
    find_by_username,
    search_users,
    group_by_theme,
    recent_users,
    count_notifications_enabled,
    average_registrations_last_30_days,
    populate_random_users, print_all_users
)

# Load environment variables from .env file
DGRAPH_URI = os.getenv('DGRAPH_URI', 'localhost:9081')




def main_menu():
    while True:
        print("\n=== NoSQL ===")
        print("1. Cassandra")
        print("2. MongoDB")
        print("3. Dgraph")
        print("0. Exit")

        opcion = input("Select an option: ")

        if opcion == "1":
            cassandra_menu()
        elif opcion == "2":
            mongo_menu()
        elif opcion == "3":
            dgraph_menu()
        elif opcion == "0":
            print("bye bye bye del programa.")
            break
        else:
            print("Opción inválida. Intenta nuevamente.")



def run_recent_logins(session):
    user = UUID(input("Enter user_id (UUID): ").strip())
    limit = int(input("How many logins to fetch? [5] ") or 5)
    rows = get_recent_logins(session, user, limit)
    print(f"\nLast {limit} logins for {user}:")
    for r in rows:
        print(" •", r.login_timestamp)


def run_posts_since(session):
    user = UUID(input("Enter user_id (UUID): ").strip())
    days = int(input("How many days back? [7] ") or 7)
    limit = int(input("How many posts to fetch? [10] ") or 10)
    since = datetime.utcnow() - timedelta(days=days)
    rows = get_user_posts_since(session, user, since, limit)
    print(f"\nPosts by {user} since {since.isoformat()} (up to {limit}):")
    for r in rows:
        print(" •", r.timestamp, r.post_id, r.content)


def run_posts_in_range(session):
    user = UUID(input("Enter user_id (UUID): ").strip())
    start_str = input("Start timestamp (YYYY-MM-DDTHH:MM:SS): ")
    end_str   = input("End   timestamp (YYYY-MM-DDTHH:MM:SS): ")
    start = datetime.fromisoformat(start_str)
    end   = datetime.fromisoformat(end_str)
    rows = get_user_posts_in_range(session, user, start, end)
    print(f"\nPosts by {user} from {start} to {end}:")
    for r in rows:
        print(" •", r.timestamp, r.post_id, r.content)


def run_recent_24h(session):
    user = UUID(input("Enter user_id (UUID): ").strip())
    rows = get_recent_posts_last_24h(session, user)
    print(f"\nPosts by {user} in the last 24h:")
    for r in rows:
        print(" •", r.timestamp)


def run_recent_visits(session):
    user = UUID(input("Enter user_id (UUID): ").strip())
    limit = int(input("How many visits to fetch? [20] ") or 20)
    rows = get_recent_page_visits(session, user, limit)
    print(f"\nLast {limit} page visits for {user}:")
    for r in rows:
        print(" •", r.visit_timestamp, r.page)


def cassandra_menu():
    cluster = None
    session = None

    while True:
        print("\n--- Cassandra Menu ---")
        print("1. Connect to Cassandra")
        print("2. Create Keyspace & Tables")
        print("3. Insert Sample Data (75 rows)")
        print("4. Insert User Login Record")
        print("5. Insert User Post")
        print("6. Insert Page Visit")
        print("7. Retrieve Recent Login Activity")
        print("8. Retrieve Recent Posts By User")
        print("9. Retrieve Posts In Date Range")
        print("10. Retrieve Recent Posts (last 24h)")
        print("11. Retrieve Recent Page Visits")
        print("12. Print All Data")
        print("13. Exit")
        choice = input("Option: ").strip()

        if choice == "1":
            cluster, session = connect()
            session.set_keyspace('myapp')
            init_queries(session)
            init_inserts(session)
            print("Connected and initialized queries & inserts.")

        elif choice == "2":
            if session:
                setup_all()
                print(" Keyspace and tables created.")
            else:
                print(" Please connect first (option 1).")

        elif choice == "3":
            if session:
                load_sample_data(session)
            else:
                print(" Please connect first.")

        elif choice == "4":
            if session:
                user = UUID(input("User UUID: "))
                insert_user_login(session, user)
                print(" Login inserted.")
            else:
                print(" Please connect first.")

        elif choice == "5":
            if session:
                user = UUID(input("User UUID: "))
                post = UUID(input("Post UUID: "))
                content = input("Content: ")
                insert_user_post(session, user, post, content)
                print(" Post inserted.")
            else:
                print(" Please connect first.")

        elif choice == "6":
            if session:
                user = UUID(input("User UUID: "))
                page = input("Page name/URL: ")
                insert_user_visit(session, user, page)
                print(" Page visit inserted.")
            else:
                print(" Please connect first.")

        elif choice == "7":
            if session:
                run_recent_logins(session)
            else:
                print(" Please connect first.")

        elif choice == "8":
            if session:
                run_posts_since(session)
            else:
                print(" Please connect first.")

        elif choice == "9":
            if session:
                run_posts_in_range(session)
            else:
                print(" Please connect first.")

        elif choice == "10":
            if session:
                run_recent_24h(session)
            else:
                print(" Please connect first.")

        elif choice == "11":
            if session:
                run_recent_visits(session)
            else:
                print(" Please connect first.")

        elif choice == "12":
            if session:
                print_all_data(session)
            else:
                print(" Please connect first.")

        elif choice == "13":
            print("Goodbye!")
            if cluster:
                cluster.shutdown()
            break

        else:
            print("Invalid option, try again.")


def mongo_menu():
    while True:
        print("\n--- MongoDB Menu ---")
        print("1. Insert sample user")
        print("2. Create indexes")
        print("3. Find by username")
        print("4. Search users (username or email)")
        print("5. Group by theme")
        print("6. Show recent users")
        print("7. Count users with notifications enabled")
        print("8. Average registrations (last 30 days)")
        print("9. Populate 50 random users")
        print("10. Show all users")
        print("0. Volver")

        choice = input("Selecciona una opción: ")

        if choice == "1":
            insert_sample_user()
        elif choice == "2":
            create_indexes()
        elif choice == "3":
            username = input("Username: ")
            print(find_by_username(username))
        elif choice == "4":
            term = input("Search term: ")
            print(search_users(term))
        elif choice == "5":
            print(group_by_theme())
        elif choice == "6":
            print(recent_users())
        elif choice == "7":
            print("Users with notifications ON:", count_notifications_enabled())
        elif choice == "8":
            print(average_registrations_last_30_days())
        elif choice == "9":
            populate_random_users()
        elif choice == "10":
            print_all_users()
        elif choice == "0":
            break
        else:
            print("Opción inválida")




def create_client_stub():
    return pydgraph.DgraphClientStub(DGRAPH_URI)

def create_client(client_stub):
    return pydgraph.DgraphClient(client_stub)

def close_client_stub(client_stub):
    client_stub.close()

def dgraph_menu():
    client_stub = create_client_stub()
    client = create_client(client_stub)

    while True:
        print("\n--- Dgraph Menu ---")
        print("1. Create schema")
        print("2. Insert data")
        print("3. Delete user by username")
        print("4. Search user (follows / followers)")
        print("5. Drop all data")
        print("6. View follows and followers data")
        print("7. View post details")
        print("8. View mutual followers")
        print("9. Search users by email domain")
        print("10. View recent posts of a user")
        print("11. Search comments by keyword")
        print("12. View top user engagement")
        print("13. Get users followed by a user (by UID)")
        print("14. Get users who liked a post")
        print("15. Count comments on a post")
        print("16. Suggest mutual friends for a user")
        print("17. Check if a user follows another")
        print("18. Get all users")
        print("0. Return to main menu")
        option = input("Option: ")

        if option == "0":
            break

        elif option == "1":
            dq.set_schema(client)
            print("Schema created.")

        elif option == "2":
            dq.create_data(client)
            print("Data inserted.")

        elif option == "3":
            username = input("Enter username to delete: ")
            dq.delete_user_by_username(client, username)

        elif option == "4":
            username = input("Enter username to search: ")
            dq.search_user(client, username)

        elif option == "5":
            dq.drop_all(client)
            print("All data dropped.")

        elif option == "6":
            username = input("Enter username: ")
            dq.get_follow_data(client, username)

        elif option == "7":
            content = input("Enter exact post content: ")
            dq.get_post_details(client, content)

        elif option == "8":
            username = input("Enter username: ")
            dq.mutual_followers(client, username)

        elif option == "9":
            domain = input("Enter email domain (e.g. @example.com): ")
            dq.search_users_by_domain(client, domain)

        elif option == "10":
            username = input("Enter username: ")
            dq.recent_posts(client, username)

        elif option == "11":
            keyword = input("Keyword to search in comments: ")
            dq.search_comments_keyword(client, keyword)

        elif option == "12":
            dq.top_user_engagement(client)

        elif option == "13":
            user_uid = input("Enter user UID: ")
            result = dq.get_users_followed_by(client, user_uid)
            print(json.dumps(result, indent=2, ensure_ascii=False))

        elif option == "14":
            post_id = input("Enter post ID: ")
            result = dq.get_users_who_liked_post(client, post_id)
            print(json.dumps(result, indent=2, ensure_ascii=False))

        elif option == "15":
            post_title = input("Enter exact post title: ")
            count = dq.count_comments_on_post(client, post_title)
            print(f"Number of comments: {count}")

        elif option == "16":
            user_uid = input("Enter user UID: ")
            result = dq.suggest_mutual_friends(client, user_uid)
            print(json.dumps(result, indent=2, ensure_ascii=False))

        elif option == "17":
            follower_uid = input("Enter follower user UID: ")
            followee_uid = input("Enter followed user UID: ")
            is_following = dq.check_if_user_follows(client, follower_uid, followee_uid)
            print(f"Does user {follower_uid} follow user {followee_uid}? {'Yes' if is_following else 'No'}")
        
        elif option == "18":
            users = dq.get_all_users(client)
            print(json.dumps(users, indent=2, ensure_ascii=False))

        else:
            print("Invalid option. Please try again.")




if __name__ == "__main__":
    main_menu()