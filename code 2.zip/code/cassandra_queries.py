# cassandra_queries.py
# cassandra_queries.py

from cassandra.cluster import Session
from cassandra.query import PreparedStatement, BoundStatement
from datetime import datetime, timedelta
from uuid import UUID

# PreparedStatement placeholders
_ps_recent_logins: PreparedStatement = None
_ps_user_posts: PreparedStatement = None
_ps_posts_date_range: PreparedStatement = None
_ps_recent_1d_posts: PreparedStatement = None
_ps_recent_visits: PreparedStatement = None


def init_queries(session: Session):
    """
    Prepare all CQL statements once. Call this after connecting and setting keyspace.
    """
    global _ps_recent_logins, _ps_user_posts, _ps_posts_date_range, _ps_recent_1d_posts, _ps_recent_visits

    _ps_recent_logins = session.prepare(
        """
        SELECT user_id, login_timestamp
          FROM user_login_history
         WHERE user_id = ?
      ORDER BY login_timestamp DESC
         LIMIT ?
        """
    )

    _ps_user_posts = session.prepare(
        """
        SELECT post_id, content, timestamp
          FROM user_post_logs
         WHERE user_id = ?
           AND timestamp >= ?
      ORDER BY timestamp DESC
         LIMIT ?
        """
    )

    _ps_posts_date_range = session.prepare(
        """
        SELECT post_id, content, timestamp
          FROM user_post_logs
         WHERE user_id = ?
           AND timestamp >= ?
           AND timestamp <= ?
        ALLOW FILTERING
        """
    )

    _ps_recent_1d_posts = session.prepare(
        """
        SELECT post_id, content, timestamp
          FROM user_post_logs
         WHERE user_id = ?
           AND timestamp >= ?
        """
    )

    _ps_recent_visits = session.prepare(
        """
        SELECT user_id, page, visit_timestamp
          FROM user_page_visits
         WHERE user_id = ?
      ORDER BY visit_timestamp DESC
         LIMIT ?
        """
    )


def get_recent_logins(session: Session, user_id: UUID, limit: int = 5):
    """
    Retrieve the last `limit` login events for a user, newest first.
    """
    bound: BoundStatement = _ps_recent_logins.bind((user_id, limit))
    return session.execute(bound)


def get_user_posts_since(session: Session, user_id: UUID, since: datetime, limit: int = 10):
    """
    Retrieve up to `limit` posts by user since a given datetime.
    """
    bound = _ps_user_posts.bind((user_id, since, limit))
    return session.execute(bound)


def get_user_posts_in_range(
    session: Session,
    user_id: UUID,
    start: datetime,
    end: datetime
):
    """
    Retrieve all posts by user within the [start, end] window. Uses ALLOW FILTERING.
    """
    bound = _ps_posts_date_range.bind((user_id, start, end))
    return session.execute(bound)


def get_recent_posts_last_24h(session: Session, user_id: UUID):
    """
    Retrieve all posts by user in the last 24 hours.
    """
    cutoff = datetime.utcnow() - timedelta(days=1)
    bound = _ps_recent_1d_posts.bind((user_id, cutoff))
    return session.execute(bound)


def get_recent_page_visits(session: Session, user_id: UUID, limit: int = 20):
    """
    Retrieve the last `limit` page visits for a user, newest first.
    """
    bound = _ps_recent_visits.bind((user_id, limit))
    return session.execute(bound)
