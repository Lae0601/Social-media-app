# sample_data.py

from uuid import UUID, uuid4
from datetime import datetime, timedelta
import random

from cassandra_inserts import init_inserts, insert_user_login, insert_user_post, insert_user_visit

def load_sample_data(session):
    """
    Inserts 75 sample rows:
      - 5 users × 5 login records each  => 25
      - 5 users × 5 post records each   => 25
      - 5 users × 5 visit records each  => 25
    """
    # Prepare our INSERT statements
    init_inserts(session)

    # Pre‑define 5 user UUIDs
    user_ids = [
        UUID('11111111-1111-1111-1111-111111111111'),
        UUID('22222222-2222-2222-2222-222222222222'),
        UUID('33333333-3333-3333-3333-333333333333'),
        UUID('44444444-4444-4444-4444-444444444444'),
        UUID('55555555-5555-5555-5555-555555555555'),
    ]

    now = datetime.utcnow()

    for user in user_ids:
        # 5 login records per user (spaced by hours)
        for i in range(5):
            ts = now - timedelta(hours= i * random.uniform(1,4))
            insert_user_login(session, user, ts)

        # 5 post records per user
        for i in range(5):
            post_id = uuid4()
            content = f"Sample post #{i+1} by user {str(user)[-4:]}"
            ts = now - timedelta(days=i, minutes=random.randint(0,59))
            insert_user_post(session, user, post_id, content, ts)

        # 5 visit records per user
        pages = ['/home', '/profile', '/search', '/settings', '/help']
        for i in range(5):
            page = random.choice(pages)
            ts = now - timedelta(days=i*2, seconds=random.randint(0,3600))
            insert_user_visit(session, user, page, ts)

    print("✅ Inserted 75 sample rows (25 logins, 25 posts, 25 visits).")
