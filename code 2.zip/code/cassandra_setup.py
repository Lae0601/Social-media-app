import cassandra
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider  # if you have auth

# 1. Connect (adjust contact_points if you ran a cluster)
def connect(contact_points=['127.0.0.1'], port=9042):
    cluster = Cluster(contact_points=contact_points, port=port)
    session = cluster.connect()
    return cluster, session

# 2. Create a keyspace
def create_keyspace(session, keyspace_name='myapp', replication_factor=1):
    cql = f"""
    CREATE KEYSPACE IF NOT EXISTS {keyspace_name}
    WITH replication = {{ 'class': 'SimpleStrategy', 'replication_factor': '{replication_factor}' }}
    """
    session.execute(cql)
    # move into it
    session.set_keyspace(keyspace_name)

# 3. Create user_login_history table
def create_user_login_history(session):
    cql = """
    CREATE TABLE IF NOT EXISTS user_login_history (
      user_id UUID,
      login_timestamp TIMESTAMP,
      PRIMARY KEY (user_id, login_timestamp)
    ) WITH CLUSTERING ORDER BY (login_timestamp DESC);
    """
    session.execute(cql)

# 4. Create user_post_logs table
def create_user_post_logs(session):
    cql = """
    CREATE TABLE IF NOT EXISTS user_post_logs (
      user_id UUID,
      timestamp TIMESTAMP,
      post_id UUID,
      content TEXT,
      PRIMARY KEY (user_id, timestamp, post_id)
    ) WITH CLUSTERING ORDER BY (timestamp DESC);
    """
    session.execute(cql)

# 5. Create user_page_visits table
def create_user_page_visits(session):
    cql = """
    CREATE TABLE IF NOT EXISTS user_page_visits (
      user_id UUID,
      visit_timestamp TIMESTAMP,
      page TEXT,
      PRIMARY KEY (user_id, visit_timestamp)
    ) WITH CLUSTERING ORDER BY (visit_timestamp DESC);
    """
    session.execute(cql)

# 6. Orchestrator: call everything
def setup_all(contact_points=['127.0.0.1'], port=9042, keyspace='myapp'):
    cluster, session = connect(contact_points, port)
    create_keyspace(session, keyspace)
    create_user_login_history(session)
    create_user_post_logs(session)
    create_user_page_visits(session)
    print("✅ Keyspace and tables created")
    cluster.shutdown()

# If run as script:
if __name__ == '__main__':
    setup_all()
