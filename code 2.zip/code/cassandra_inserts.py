# cassandra_inserts.py

from cassandra.cluster import Session
from cassandra.query import PreparedStatement, BoundStatement
from uuid import UUID
from datetime import datetime

# module‑level placeholders for our prepared INSERTs
_ps_insert_login: PreparedStatement = None
_ps_insert_post: PreparedStatement = None
_ps_insert_visit: PreparedStatement = None

def init_inserts(session: Session):
    """
    Prepare the INSERT statements once.
    Call this after init_queries() in your setup.
    """
    global _ps_insert_login, _ps_insert_post, _ps_insert_visit

    _ps_insert_login = session.prepare("""
        INSERT INTO user_login_history (user_id, login_timestamp)
        VALUES (?, ?)
    """)

    _ps_insert_post = session.prepare("""
        INSERT INTO user_post_logs (user_id, timestamp, post_id, content)
        VALUES (?, ?, ?, ?)
    """)

    _ps_insert_visit = session.prepare("""
        INSERT INTO user_page_visits (user_id, visit_timestamp, page)
        VALUES (?, ?, ?)
    """)

def insert_user_login(session: Session, user_id: UUID, login_ts: datetime = None):
    """
    Inserts one login record. If login_ts is None, uses now().
    """
    login_ts = login_ts or datetime.utcnow()
    bound: BoundStatement = _ps_insert_login.bind((user_id, login_ts))
    session.execute(bound)

def insert_user_post(
    session: Session,
    user_id: UUID,
    post_id: UUID,
    content: str,
    ts: datetime = None
):
    """
    Inserts one post record. If ts is None, uses now().
    """
    ts = ts or datetime.utcnow()
    bound = _ps_insert_post.bind((user_id, ts, post_id, content))
    session.execute(bound)

def insert_user_visit(
    session: Session,
    user_id: UUID,
    page: str,
    visit_ts: datetime = None
):
    """
    Inserts one page‑visit record. If visit_ts is None, uses now().
    """
    visit_ts = visit_ts or datetime.utcnow()
    bound = _ps_insert_visit.bind((user_id, visit_ts, page))
    session.execute(bound)

def print_all_data(session):
    """
    Retrieve and print every row from all three tables.
    """
    print("\n=== User Login History ===")
    rows = session.execute("SELECT user_id, login_timestamp FROM user_login_history")
    for r in rows:
        print(f"user_id={r.user_id}, login_timestamp={r.login_timestamp}")

    print("\n=== User Post Logs ===")
    rows = session.execute(
        "SELECT user_id, timestamp, post_id, content FROM user_post_logs"
    )
    for r in rows:
        print(f"user_id={r.user_id}, timestamp={r.timestamp}, post_id={r.post_id}, content={r.content}")

    print("\n=== User Page Visits ===")
    rows = session.execute(
        "SELECT user_id, visit_timestamp, page FROM user_page_visits"
    )
    for r in rows:
        print(f"user_id={r.user_id}, visit_timestamp={r.visit_timestamp}, page={r.page}")